import { Application, Router } from "https://deno.land/x/oak@v6.5.0/mod.ts";
import { bold, yellow } from "https://deno.land/std@0.87.0/fmt/colors.ts";
import { createHash } from "https://deno.land/std@0.81.0/hash/mod.ts";

const app = new Application();
const router = new Router();

router.get("/", async (ctx) => {
  ctx.response.body = await Deno.readTextFile("index.html");
});

router.get("/flag", async (ctx) => {
  const auth = ctx.request.headers.get('authorization') ?? '';
  const hasher = createHash("md5");
  hasher.update(auth);
  // NOTE: this is stupid and annoying. remove?
  // FIXME? crackstation.net knows this hash
  if (hasher.toString("hex") === "e7552d9b7c9a01fad1c37e452af4ac95") {
    ctx.response.body = await Deno.readTextFile("flag");
  } else {
    ctx.response.status = 403;
    ctx.response.body = 'go away';
  }
});

router.post("/query", async (ctx) => {
  if (!ctx.request.hasBody) {
    ctx.response.status = 400;
    return;
  }
  const body = ctx.request.body();
  if (body.type !== "json") {
    ctx.response.status = 400;
    ctx.response.body = "expected json body";
    return;
  }
  const { path, start, end } = await body.value;
  const text = await Deno.readTextFile(path);
  const charset = new Set(text.slice(start, end));
  ctx.response.type = "application/json";
  ctx.response.body = JSON.stringify({
    "range-entropy": charset.size,
  });
});

app.use(router.routes());
app.use(router.allowedMethods());

app.addEventListener("listen", ({ hostname, port }) => {
  console.log(
    bold("Start listening on ") + yellow(`${hostname}:${port}`),
  );
});

await app.listen({ hostname: "0.0.0.0", port: 1024 });